(function($){

	'use strict';

	TF.Collections.ElementStyles = Backbone.Collection.extend({
		model: TF.Models.ElementStyle
	});
	
})(jQuery);