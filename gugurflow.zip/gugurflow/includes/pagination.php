<?php
/**
 * Post Pagination Template.
 * 
 * @package gugurFlow
 * @since 1.0.0
 */
tf_pagenav();