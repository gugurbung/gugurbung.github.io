<?php
/**
 * Template for gugurcommerce pages
 * 
 * @package gugurFlow
 * @since 1.0.0
 */

add_action( 'tf_template_render_content', 'gugurcommerce_content' );

do_action( 'tf_template_render', basename( __FILE__ ) );